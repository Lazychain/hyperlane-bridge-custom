
import TransferTokenCard from "@/features/transfer/TransferTokenCard";
import { SolidButton} from "@/components/buttons/SolidButton";
import { Header } from "@/components/nav/Header";
import { Footer } from "@/components/nav/Footer";
import MenuIcon from "@/components/nav/Menu";

export default function RootLayout({
    children,
  }: {
    children: React.ReactNode
  }) {
    return (
        
      <html lang="en">
        <body>
            <main className="pt-5 space-y-3">
               
               <MenuIcon />
                
                {children}
            </main>
        </body>
      </html>
        
        
 
    )
  }
  