import { Bungee_Shade } from 'next/font/google'

export const bungee_shade = Bungee_Shade({ weight: '400', subsets: ['latin'] });

