// Lo que ponga aca afecta a todas las paginas
// por ejemplo un header, un footer
// serian cosas que quiero que aparezcan en todas las paginas

//import localFont from "next/font/local";
/*import "./globals.css";
import { bungee_shade } from './fonts/fonts';
import Image from "next/image";
import logo from "../../public/svgviewer-output.svg";
import MenuIcon from "../ui/componentes/menu";*/



/*const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});*/


//import type { AppProps } from 'next/app';




/*export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <header className="pt-4">
          <nav className="flex justify-around items-center" >
            <div className="flex justify-start items-center p-2">
              <Image className="mt-2 self-center" src={logo} alt="Logo de LazyChain" width={50} height={50}></Image>
              <h1 className={`${bungee_shade.className} pl-2 text-5xl text-[#b158FE] antialiased`}>LazyChain</h1>
            </div>
            <div>
              <MenuIcon />
            </div>
          </nav>
        </header>
        <footer></footer>
        {children} 
      </body>
    </html>
  );
}*/



